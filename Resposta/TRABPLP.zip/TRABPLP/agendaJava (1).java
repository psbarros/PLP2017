import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;
 
public class agendaJava {
 
    private String nomeDoArquivo;
 
    public agendaJava(String nomeArquivo) {
        this.nomeDoArquivo = nomeArquivo;
    }
 
    public void inserirDados(String registro) {
        File fArquivo = null;
        try {
            fArquivo = new File(this.nomeDoArquivo);
            FileWriter fwArquivo = null;
 
            
            if (fArquivo.exists() == true) {
                fwArquivo = new FileWriter(fArquivo, true);
            } else {
                fwArquivo = new FileWriter(fArquivo);
            }
 
            BufferedWriter bw = new BufferedWriter(fwArquivo);
 
            
            bw.write(registro + "\n");
 
            System.out.println("Registro adicionado com sucesso...");
 
            
            bw.close();
            fwArquivo.close();
 
        } catch (Exception e) {
            System.err.println("Erro ao inserir linhas no arquivo: " + fArquivo);
        }
    }
    public void excluir(){
    	System.out.println("digite o contato formato = (nome:numero): ");
    	Scanner teclado = new Scanner(System.in);
    	String nome = teclado.nextLine();
        File fil = new File("agendaJava.txt");
        
        try{     
            FileReader fr = new FileReader(fil);
            BufferedReader br = new BufferedReader(fr);
            
            FileWriter fw = new FileWriter(fil);
            BufferedWriter bw = new BufferedWriter (fw);
            
            String linha = br.readLine();
            ArrayList<String> salvar = new ArrayList();
            while(linha != null){
                
                if(linha.equals(nome)==false){
                    salvar.add(linha);
                    
                }
                
            }
            br.close();
            fr.close();
            FileWriter fw2= new FileWriter(fil,true);
            fw2.close();
            
            
            FileWriter fw1 = new FileWriter(fil);
            BufferedWriter bw1 = new BufferedWriter(fw1);
            
            for (int i =0; i<salvar.size(); i++){
                bw1.write(salvar.get(i));
                bw1.newLine();
                        
            }
            bw1.close();
            fw1.close();
            
            
            }catch(IOException ex){
            }
        }

    public void listarDados() {
        Scanner lendoArquivo = null;
        File arquivo = null;
        try {
            
            arquivo = new File(this.nomeDoArquivo);
            lendoArquivo = new Scanner(arquivo);
 
            
            while (lendoArquivo.hasNextLine()) {
                this.processandoLinha(lendoArquivo.nextLine());
            }
 
 
        } catch (FileNotFoundException e) { 
            System.err.println("Erro: arquivo nao existe. " + arquivo);
        } finally {
            
            try {
                lendoArquivo.close();
            } catch (Exception e) {
            }
        }
    }
 
    private void processandoLinha(String linha) {
        
        if (linha != null) {
            // separando os campos através do delimitador ':'
            String[] campos = linha.split(":");
 
            System.out.print("Nome: " + campos[0].trim());
            System.out.println("\tFone: " + campos[1].trim());
            System.out.println("--------------------------------------\n");
        }
    }
 
    public void menu() {
        
        Scanner teclado = new Scanner(System.in);
        int op = 0;
        do {
            
            System.out.println("1 - Inserir linha");
            System.out.println("2 - Listar todo arquivo");
            System.out.println("3 - excluir");
            System.out.println("4 - sair");

            System.out.print("Entre com uma opcao: ");
            op = teclado.nextInt();
 
            switch (op) {
                case 1:
                    teclado.nextLine();
                    String nome;
                    String telefone;
                    System.out.println("Entre com os dados:");
                    System.out.print("Nome: ");
                    nome = teclado.nextLine();
                    System.out.print("Fone: ");
                    telefone = teclado.nextLine();
                    this.inserirDados(nome + ":" + telefone);
                    break;
                case 2:
                    this.listarDados();
                    break;
                case 3:
                	this.excluir();
                	break;
                default:
                    System.out.println("Opção inválida!");
            }
 
        } while (op != 4);
    }
     public static void main(String[] args) {
 
        agendaJava p = new agendaJava("agendaJava.txt");
 
        p.menu();
    }
}