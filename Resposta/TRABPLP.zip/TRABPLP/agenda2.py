agenda = []

# Variável para marcar uma alteração na agenda
alterada = False

def inserirNomeTelefone():
    nome=input("Digite o nome: ")
    numero=input("Digite o numero: ")
    arquivo = open('agenda.txt', 'r')
    texto = arquivo.readlines()
    texto.append(nome + " ")
    texto.append(numero + "\n")
    arquivo = open('agenda.txt', 'w')
    arquivo.writelines(texto)
    arquivo.close()

def listar():
    arquivo = open('agenda.txt', 'r')
    for line in arquivo:
        print(line)
        
def remover(nome):
    novonome = nome + "\n";
    arquivo = open('agenda.txt', 'r')
    agenda = arquivo.readlines()
    #print(agenda)
    for i in range(len(agenda) - 1):
        if novonome in agenda:
            agenda.remove(novonome)
    #print(agenda)
    arquivo = open('agenda.txt', 'w')
    arquivo.writelines(agenda)
    arquivo.close()
    
def menu():
     print("""
   1 - Novo Contato 

   2 - Listar Contatos

   3 - Remover Contato

   0 - Sair """)
     print("\nNomes na agenda: %d Alterada: %s\n" % (len(agenda), alterada))
     print("Escolha uma opção: ")

while True:
     menu()
     opção = int(input())
     if opção == 0:
         break
     elif opção == 1:
         inserirNomeTelefone()
     elif opção == 2:
         listar()
     elif opção == 3:
         remover(input("""Digite o nome e número do contato que deseja excluir (separados por um espaço): """))
