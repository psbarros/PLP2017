# -*- coding: utf-8 -*-
from inspect import getmro
from pygraphviz import *
from PIL import Image

#MetaClasse usado para guardar quais classes estão sendo criadas
class MetaClasse(type):
   
   listOfClasses = list()
   listOfInstances = list()
   listOfClassesName = list()
   
   def __new__(self, namecls, bases, dct):
      print 50*'-'
      print "__new__: Aloca memoria para classe ", namecls
      print [self, bases, dct]
      # garante criacao normal que seria feita por type de qq modo:
      #return super(minhaMetaClasse,self).__new__(meta,namemeta,bases,dct)
      return type.__new__(self, namecls, bases, dct)
            
   def __init__(self, namecls, bases, dct):
      print 50*'-'
      print "__init__: Inicia classe", namecls
      print [self, bases, dct]
      MetaClasse.listOfClasses.append(namecls)
      MetaClasse.listOfClassesName.append(str(self))
      print "lista: " + str(MetaClasse.listOfClasses)
      super(MetaClasse, self).__init__(namecls, bases, dct)

   def __call__(self, *args, **kwargs):
      print 50*'-'
      print '__call__: Chamada de classe', str(self)
      print '__call__ *args=', str(args), '*kwargs=', str(kwargs)
      return type.__call__(self, *args, **kwargs)


#As classes herdam o metodo GETNAME GETATTRBUTES GETATTRBUTES GETMETODOS de TableClass
#Usado para conseguir as informações de atributos e métodos das classes
#para alimentar o Diagrama de Classe
   
class TableClass(object):
   graph = AGraph()
   
   def getAll(self):
      """getAll/TableClass"""
      print 'Classe: ',
      cnome = [x.__name__ for x in getmro(self.__class__)]
      for i in range(1, len(cnome)):
         print cnome[-i], "->",
      print cnome[0]
      print 'Descricao: ', self.__doc__
      print 'Atributos: '
      atributos = self.__dict__
      for k in atributos:
         print "   ", k, ":", atributos[k]
      print 'Metodos: '
      for n in dir(self):
         a = getattr(self, n)
         if callable(a):
            if (n[0] != "_" and n[1] != "_"):
               print "   ", n, ":", a.__doc__

   def getParentClass(self):
      parentClass = self.__doc__
      #print parentClass
      if parentClass != None:
         parentClass = parentClass.split("/")
      return parentClass
   
   def getName(self):
      """getName/TableClass"""
     # print 'Classe: ',
      cnome = [x.__name__ for x in getmro(self.__class__)]
      return str(cnome[0])

   def getAttributes(self):
      """getAttributes/TableClass"""
      listAttributes = list()
      atributos = self.__dict__
      for k in atributos:
         print "   ", k, ":", atributos[k]
         flag_recursividade = False
         aux = atributos[k]
         aux = aux[0:-1]
         aux = aux.split("(")
         if aux[0] == "Char":
            sttr = aux[1]
            sttr = sttr.split(",")
            aux = aux[0] + "(" + sttr[0] + ")"
         elif aux[0] == "Boolean" or aux[0] == "Date" or aux[0] == "String" or aux[0] == "Integer" or aux[0] == "Float" or aux[0] == "DateTime":
            aux = aux[0]
         elif aux[0] == self.getName():
            print "\nHouve uma declaracao recursiva na classe: "+ self.getName()+" , mas, foi ignorado pelas definicoes do trabalho\n"
            flag_recursividade = True
         else:
            sttr = aux[1]
            sttr = sttr.split(",")
            sttr = sttr[0]
            if len(sttr) > 1:
               #sttr = sttr[0]
               aux = aux[0] + "(" + sttr + ")"
            else:
               #sttr = sttr[0]
               aux = aux[0]               
         print aux
         if flag_recursividade == False:
            listAttributes.append(str(k) + ":" +str(aux))
      return listAttributes

   def getAttributesToEdge(self):
      """getAttributesToEdge/TableClass"""
      listAttributes = list()
      atributos = self.__dict__
      for k in atributos:
         print "   ", k, ":", atributos[k]
         listAttributes.append(str(k) + ":" +str(atributos[k]))
      return listAttributes

   def getMethods(self):
      """getMethods/TableClass"""
     # print 'Metodos: '
      cnome = [x.__name__ for x in getmro(self.__class__)]
      listMethods = list()
      for n in dir(self):
         a = getattr(self, n)
         if callable(a):
            classe = str(a.__doc__).split("/")
            if (n[0] != "_" and n[1] != "_" and cnome[0] == classe[0]):
               listMethods.append(str(n) + ":" + str(a.__doc__))
               print "   ", n, ":", a.__doc__
      return listMethods


   @staticmethod
   def showModel(roles = True):
      if len(MetaClasse.listOfClasses) > 0 and len(MetaClasse.listOfInstances) > 0:
         TableClass.graph = AGraph()
         TableClass.graph = TableClass.createGraph()
         TableClass.graph = TableClass.createNodes()
         TableClass.graph = TableClass.addAttributes()
         TableClass.graph = TableClass.addMethods()
         TableClass.graph = TableClass.addAssociationEdgeOnGraph(roles)
         TableClass.graph = TableClass.addGeneralizationEdgeOnGraph()
         TableClass.exportToPng()
      else:
         print "No classes and instances have been registered yet."

   #Neste metodo eh configurado o design do desenho do diagrama de classe
   @classmethod   
   def createGraph(cls):
      print cls.graph
      cls.graph.node_attr['style']='filled'
      cls.graph.node_attr['shape']='record'
      cls.graph.node_attr['fixedsize']='false'
      cls.graph.node_attr['fontcolor']='#000000'
      cls.graph.node_attr['fillcolor']="#FFFFC2"
      cls.graph.node_attr['rankdir'] = 'LR'
      return cls.graph

   #Neste metodo eh criado as caixas de cada classe no diagrama de classe
   @classmethod
   def createNodes(cls):      
      cls.graph.add_nodes_from(MetaClasse.listOfClasses)
      return cls.graph
   
   #Neste metodo eh adicionado os atributos em cada classe no diagrama
   @classmethod
   def addAttributes(cls):
      print cls.graph
      for k in MetaClasse.listOfInstances:
         listOfAttributes = k.getAttributes()
         node = cls.graph.get_node(k.getName())
         if(node != None):
            string = "{ " + k.getName() + " | {"
            for i in listOfAttributes:
               string = string + "+" + i + "&#92;n"
            string = string + "}}"
            node.attr['label'] = string
      return cls.graph

   #Neste metodo eh adicionado os metodos em cada classe no diagrama
   @classmethod
   def addMethods(cls):
      for k in MetaClasse.listOfInstances:
         listOfMethods = k.getMethods()
         node = cls.graph.get_node(k.getName())
         if(node != None):
            string = node.attr['label']
            #print "STRING: " + string
            string = string[0:-1] + " | { "
            for i in listOfMethods:
               attributesOfMethods = i.split(k.getName())
               #escreve o metodo e seus parametros no diagrama
               for atr in attributesOfMethods:
                  #escrevendo o nome do metodo no diagrama
                  if atr == attributesOfMethods[0]:
                     string = string + "+" + atr + "("
                  else:
                     #escreve os parametros do metodo, caso tenha / eh eliminado a barra
                     if atr.find("/") != -1:
                        atr = atr[1:len(atr)]
                     string = string + atr + ","
                     
               #string[0:-1] eh para eliminar o ultimo "," concatenado      
               string = string[0:-1] + ")" + "&#92;n"
            string = string + "}}"
            node.attr['label'] = string
      return cls.graph


   #Neste metodo eh adicionado as arestas de associacao do diagrama de classe
   @classmethod
   def addAssociationEdgeOnGraph(cls, roles):
      #print "addEdgeOnGraph Function"
      for k in MetaClasse.listOfInstances:
         listOfAttributes = k.getAttributesToEdge()
         #node = cls.graph.get_node(k.getName())
         #if(node != None):
         for i in listOfAttributes:
            if TableClass.IsAttributeClass(i, k)  == True:
               print "EDGE ACTIVE"
               auxClass = i.split(":")
               nameClass = auxClass[0]
               cardinalidadeClass = auxClass[1]
               cardinalidadeClass = cardinalidadeClass.split(",")
               if roles == True:
                  if len(cardinalidadeClass) > 1:               
                     cls.graph.add_edge(k.getName(), TableClass.getNameAttribute(i), dir = "forward", arrowhead = "open", arrowtail = "open", color = "blue", label = "1..*" + "&#92;n" + nameClass)
                  else:
                     cls.graph.add_edge(k.getName(), TableClass.getNameAttribute(i), dir = "forward", arrowhead = "open", arrowtail = "open", color = "blue", label = "1" + "&#92;n" + nameClass)
               else:               
                  cls.graph.add_edge(k.getName(), TableClass.getNameAttribute(i), dir = "forward", arrowhead = "open", arrowtail = "open", color = "blue", label = "")
                  
      return cls.graph

   #Neste metodo eh verificado se o atributo eh uma classe, isto eh, uma associacao
   @classmethod
   def IsAttributeClass(cls, attribute, instance):
      #Nao pode ter RECURSAO segundo especificacao tecnica do trabalho
      atr = attribute[0:-1]
      atr = atr.split(":")
      atr = atr[1]
      atr = atr.split("(")
      if atr[0] == "List" or atr[0] == "Vector" or atr[0] == "Enum":
         atr = atr[1].split(",")
         atr = atr[0]
      else:
         atr = atr[0]
      for i in MetaClasse.listOfClasses:
         #print "instance: "+ instance.getName() + " attribute: "+ atr
         if instance.getName() != atr and atr == i:
            return True
      return False

   #Neste metodo eh recuperado o atributo de uma classe
   @classmethod
   def getNameAttribute(cls, attribute):
      atr = attribute[0:-1]
      atr = atr.split(":")
      atr = atr[1]
      atr = atr.split("(")
      if atr[0] == "List" or atr[0] == "Vector" or atr[0] == "Enum":
         atr = atr[1].split(",")
         atr = atr[0]
      else:
         atr = atr[0]
      return atr
   
   #Neste metodo eh adicionado as arestas de generalizacao do diagrama de classe
   @classmethod
   def addGeneralizationEdgeOnGraph(cls):
      for k in MetaClasse.listOfInstances:      
         parentClass = k.getParentClass()
         if parentClass != None:
            for i in parentClass:
               if i != 'TableClass':
                  cls.graph.add_edge(k.getName(),i, dir = "forward", arrowhead = "empty", arrowtail = "empty", color = "red")   
         print "Generalization: " + str(parentClass)
      #print cls.graph
      return cls.graph

   #Neste metodo eh exportado para formato PNG o diagrama de classe
   @classmethod
   def exportToPng(cls):
      try:
         print cls.graph
         #print TableClass.graph
         #print(graph.string()) # print to screen
         cls.graph.write("graph.dot") # write to graph.dot
         cls.graph.draw('graph.png', format='png',prog='dot')
         im = Image.open("graph.png")
         im.show()
      except:
         print "Algum problema em exportar o diagrama para PNG ou exibir a imgem gerada" 

   #Neste metodo o usuario deve passar somente uma lista que contem uma instancia de cada classe para a interface
   #com as instancias na interface eh possivel capturar os metodos e os atriutos da classe
   #para alimentar o desenho do diagrama de classe
   @classmethod
   def addInstancesToGraph(cls, instances):
      try:
         MetaClasse.listOfInstances = list()
         for k in instances:
            flag = False
            for i in MetaClasse.listOfClasses:
               if k.getName() == i:
                  flag = True
                  MetaClasse.listOfInstances.append(k)
                  break
            if flag == False:
               print "Instancia pertencente a classe: " + k.getName() + " nao faz parte das classes declaradas via metaprogramacao com a metaclasse: __metaclass__ = MetaClasse "
         print MetaClasse.listOfInstances
      except:
         print "Voce pode estah adicionando alguma instancia nao descendente de TableClass"

   @classmethod
   def clear(cls):
      MetaClasse.listOfClasses = list()
      MetaClasse.listOfInstances = list()
      MetaClasse.listOfClassesName = list()

   @classmethod
   def showClasses(cls):
      if len(MetaClasse.listOfClassesName) > 0: 
         print MetaClasse.listOfClassesName
      else:
         print "No classes and instances have been registered yet."
      


      
