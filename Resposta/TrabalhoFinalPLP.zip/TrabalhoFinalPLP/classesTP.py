# -*- coding: utf-8 -*-
class Pessoa(TableClass):
   __metaclass__ = MetaClasse
   def __init__(self):
      self.RG = "Char(11, restrictions = 'unique')"
      self.nome = "Char(40)"
      self.email = "Char(30)"
      self.dtnasc = "Date()"
      self.telefones = "List(String)"
   def find_criteria(self, criteria):
      """Pessoa/criteria"""
      pass
   def set_email(self, e):
      """Pessoa/e"""
      self.email = e

class Emprestimo(TableClass):
   __metaclass__ = MetaClasse
   def __init__(self):
      self.aluno = "Aluno()"
      self.livro = "List(Livro, min=1)" # pelo menos, 1 livro
      self.data = "Date()"
      self.devolucao = "Date()"
   def cancelar(self):
      """Emprestimo"""
      pass
   def renovar(self, nv_data):
      """Emprestimo/nv_data"""
      pass

class Aluno(Pessoa):
   """Pessoa"""
   __metaclass__ = MetaClasse
   def __init__(self):
      self.matricula = "Char(10, restrictions = 'unique')"
      self.finalista = "Boolean()"
   def find_criteria(criteria):
      # método redefinido da classe Pessoa
      """Aluno/criteria"""
      pass

class Livro(TableClass):
   __metaclass__ = MetaClasse
   def __init__(self):
      self.titulo = "String()"
      self.autores = "List(String)"
   def browse(self, sch_criteria):
      """Livro/sch_criteria"""
      pass
   
