Executar o arquivo grid.py

Instruções:
+ F C X Y - criar uma figura
- F C X Y - apagar uma figura
m F C X Y - mover uma figura


F = forma (s = quadrado, c = circulo)
C = cor (qualquer cor aceita pelo tkinter/canvas)
X, Y = coordenadas

Exemplos:
+ s blue 2 2
- s blue 2 3
+ c red 2 3
- c red 2 3
